- unzip data directory:

- from command line run:

java -jar weka.pas.jar