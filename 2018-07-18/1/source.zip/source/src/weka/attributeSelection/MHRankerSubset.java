
package weka.attributeSelection;

import weka.core.*;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * <!-- globalinfo-start --> Modified Huffman Ranker MHR: <br/>
 * <br/>
 * Ranks attributes by their individual evaluations. Use in conjunction with
 * attribute evaluators (ReliefF, GainRatio, PAS, etc).<br/>
 * <p/>
 * <!-- globalinfo-end -->
 * <p>
 * <!-- options-start --> his search method should have no configuration properties attached to it. However,
 * as Weka demand the search method to extend one of it's pre-existed search method classes so I've set MHRanker
 * to extend Ranker class and thus we have some properties we do not really need. It is showing in the algorithm
 * option window but without any use.
 * <!-- options-end -->
 *
 * @author sami
 */
public class MHRankerSubset
        extends Ranker {

    /**
     * for serialization
     */
    static final long serialVersionUID = -9186714847510751944L;

    private int m_huffmanSubset;

    private double numAttsToSelect = 0;
    /**
     * Holds the starting set as an array of attributes
     */
    private int[] m_starting;

    /**
     * Holds the start set for the search as a range
     */
    private Range m_startRange;

    /**
     * Holds the ordered list of attributes
     */
    private int[] m_attributeList;

    /**
     * Holds the list of attribute merit scores
     */
    private double[] m_attributeMerit;

    /**
     * Data has class attribute---if unsupervised evaluator then no class
     */
    private boolean m_hasClass;

    /**
     * Class index of the dataset if supervised evaluator
     */
    private int m_classIndex;

    /**
     * The number of attribtes
     */
    private int m_numAttribs;

    /**
     * The number of attributes to select. -1 indicates that all attributes are to
     * be retained. Has precedence over m_frequencyThreshold
     */
    private int m_numToSelect = -1;

    /**
     * Used to compute the number to select
     */
    private int m_calculatedNumToSelect = -1;

    /**
     * Returns a string describing this search method
     *
     * @return a description of the search suitable for displaying in the
     * explorer/experimenter gui
     */
    public String globalInfo() {
        return "MHRankerSubSet : \n\nModified Huffman Ranker which ranks attributes by their individual evaluations. "
                + "Use in conjunction with attribute evaluators (ReliefF, GainRatio, "
                + "etc).\n";
    }

    /**
     * Constructor
     */
    public MHRankerSubset() {
        resetOptions();
    }

    /**
     * Returns the tip text for this property
     *
     * @return tip text for this property suitable for displaying in the
     * explorer/experimenter gui
     */
    public String numToSelectTipText() {
        return "Specify the number of attributes to retain. The default value "
                + "(-1) indicates that all attributes are to be retained. Use either "
                + "this option or a threshold to reduce the attribute set.";
    }

    /**
     * Specify the number of attributes to select from the ranked list. -1
     * indicates that all attributes are to be retained.
     *
     * @param n the number of attributes to retain
     */
    @Override
    public void setNumToSelect(int n) {
        //TODO disabled by sami, to be deleted later
//        m_numToSelect = n;
    }

    /**
     * Gets the number of attributes to be retained.
     *
     * @return the number of attributes to retain
     */
    @Override
    public int getNumToSelect() {
        return m_numToSelect;
    }

    /**
     * Gets the calculated number to select. This might be computed from a
     * threshold, or if < 0 is set as the number to select then it is set to the
     * number of attributes in the (transformed) dataset.
     *
     * @return the calculated number of attributes to select
     */
    @Override
    public int getCalculatedNumToSelect() {
        if (m_numToSelect >= 0) {
            m_calculatedNumToSelect =
                    m_numToSelect > m_attributeMerit.length ? m_attributeMerit.length
                            : m_numToSelect;
        }
        return m_calculatedNumToSelect;
    }


    /**
     * This is a dummy method. Ranker can ONLY be used with attribute evaluators
     * and as such can only produce a ranked list of attributes
     *
     * @return true all the time.
     */
    @Override
    public boolean getGenerateRanking() {
        return true;
    }

    /**
     * Returns the tip text for this property
     *
     * @return tip text for this property suitable for displaying in the
     * explorer/experimenter gui
     */
    public String startSetTipText() {
        return "Specify a set of attributes to ignore. "
                + " When generating the ranking, L2AboveFrequencySubset will not evaluate the attributes "
                + " in this list. " + "This is specified as a comma "
                + "seperated list off attribute indexes starting at 1. It can include "
                + "ranges. Eg. 1,2,5-9,17.";
    }

    /**
     * Sets a starting set of attributes for the search. It is the search method's
     * responsibility to report this start set (if any) in its toString() method.
     *
     * @param startSet a string containing a list of attributes (and or ranges),
     *                 eg. 1,2,6,10-15.
     * @throws Exception if start set can't be set.
     */
    @Override
    public void setStartSet(String startSet) throws Exception {
        m_startRange.setRanges(startSet);
    }

    /**
     * Returns a list of attributes (and or attribute ranges) as a String
     *
     * @return a list of attributes (and or attribute ranges)
     */
    @Override
    public String getStartSet() {
        return m_startRange.getRanges();
    }


    /**
     * converts the array of starting attributes to a string. This is used by
     * getOptions to return the actual attributes specified as the starting set.
     * This is better than using m_startRanges.getRanges() as the same start set
     * can be specified in different ways from the command line---eg 1,2,3 == 1-3.
     * This is to ensure that stuff that is stored in a database is comparable.
     *
     * @return a comma seperated list of individual attribute numbers as a String
     */
    private String startSetToString() {
        StringBuffer FString = new StringBuffer();
        boolean didPrint;

        if (m_starting == null) {
            return getStartSet();
        }

        for (int i = 0; i < m_starting.length; i++) {
            didPrint = false;

            if ((m_hasClass == false) || (m_hasClass == true && i != m_classIndex)) {
                FString.append((m_starting[i] + 1));
                didPrint = true;
            }

            if (i == (m_starting.length - 1)) {
                FString.append("");
            } else {
                if (didPrint) {
                    FString.append(",");
                }
            }
        }
        return FString.toString();
    }

    /**
     * Kind of a dummy search algorithm. Calls a Attribute evaluator to evaluate
     * each attribute not included in the startSet and then sorts them to produce
     * a ranked list of attributes.
     *
     * @param ASEval the attribute evaluator to guide the search
     * @param data   the training instances.
     * @return an array (not necessarily ordered) of selected attribute indexes
     * @throws Exception if the search can't be completed
     */
    @Override
    public int[] search(ASEvaluation ASEval, Instances data) throws Exception {
        int i, j;

        if (!(ASEval instanceof AttributeEvaluator)) {
            throw new Exception(ASEval.getClass().getName() + " is not a"
                    + "Attribute evaluator!");
        }

        m_numAttribs = data.numAttributes();

        if (ASEval instanceof UnsupervisedAttributeEvaluator) {
            m_hasClass = false;
        } else {
            m_classIndex = data.classIndex();
            if (m_classIndex >= 0) {
                m_hasClass = true;
            } else {
                m_hasClass = false;
            }
        }

        // get the transformed dataset and check to see if the transformer
        // preserves a class index
        if (ASEval instanceof AttributeTransformer) {
            data = ((AttributeTransformer) ASEval).transformedHeader();
            if (m_classIndex >= 0 && data.classIndex() >= 0) {
                m_classIndex = data.classIndex();
                m_hasClass = true;
            }
        }

        m_startRange.setUpper(m_numAttribs - 1);
        if (!(getStartSet().equals(""))) {
            m_starting = m_startRange.getSelection();
        }

        int sl = 0;
        if (m_starting != null) {
            sl = m_starting.length;
        }
        if ((m_starting != null) && (m_hasClass == true)) {
            // see if the supplied list contains the class index
            boolean ok = false;
            for (i = 0; i < sl; i++) {
                if (m_starting[i] == m_classIndex) {
                    ok = true;
                    break;
                }
            }

            if (ok == false) {
                sl++;
            }
        } else {
            if (m_hasClass == true) {
                sl++;
            }
        }

        m_attributeList = new int[m_numAttribs - sl];
        m_attributeMerit = new double[m_numAttribs - sl];

        // add in those attributes not in the starting (omit list)
        for (i = 0, j = 0; i < m_numAttribs; i++) {
            if (!inStarting(i)) {
                m_attributeList[j++] = i;
            }
        }

        AttributeEvaluator ASEvaluator = (AttributeEvaluator) ASEval;

        for (i = 0; i < m_attributeList.length; i++) {
            m_attributeMerit[i] = ASEvaluator.evaluateAttribute(m_attributeList[i]);
        }

        double[][] tempRanked = rankedAttributes();
        int[] rankedAttributes = new int[m_attributeList.length];

        for (i = 0; i < m_attributeList.length; i++) {
            rankedAttributes[i] = (int) tempRanked[i][0];
        }

        return rankedAttributes;
    }

    /**
     * Sorts the evaluated attribute list
     *
     * @return an array of sorted (highest eval to lowest) attribute indexes
     * @throws Exception of sorting can't be done.
     */
    @Override
    public double[][] rankedAttributes() throws Exception {
        int i, j;

        if (m_attributeList == null || m_attributeMerit == null) {
            throw new Exception("Search must be performed before a ranked "
                    + "attribute list can be obtained");
        }

        int[] ranked = Utils.sort(m_attributeMerit);
        // reverse the order of the ranked indexes
        double[][] bestToWorst = new double[ranked.length][2];

        for (i = ranked.length - 1, j = 0; i >= 0; i--) {
            bestToWorst[j++][0] = ranked[i];
        }

        // convert the indexes to attribute indexes
        for (i = 0; i < bestToWorst.length; i++) {
            int temp = ((int) bestToWorst[i][0]);
            bestToWorst[i][0] = m_attributeList[temp];
            bestToWorst[i][1] = m_attributeMerit[temp];
        }

        if (m_numToSelect <= 0) {
            determineNumToSelectFromHuffmanThreshold(bestToWorst);
        }

        return bestToWorst;
    }


    private void determineNumToSelectFromHuffmanThreshold(double[][] ranking) {
        double[] values = Arrays.stream(ranking)
                .mapToDouble(i -> i[1])
                .toArray();

        final double sumValue = Arrays.stream(values).sum();
        if (sumValue == 0) throw new NullPointerException("Max Rank Can not be Zero !!");
        numAttsToSelect = huffman(values);

        m_huffmanSubset = (int) Math.ceil(numAttsToSelect);

        m_calculatedNumToSelect = Math.min(m_huffmanSubset, values.length);
    }


    /**
     * returns a description of the search as a String
     *
     * @return a description of the search
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("\tModified Huffman Based Attribute Ranking.\n");

        if (m_starting != null) {
            sb.append("\tIgnored attributes: ");

            sb.append(startSetToString());
            sb.append("\n");
        }

        sb.append(String.format("\n\tNumber of attributes to be selected : %2.2f\n\n", numAttsToSelect));

        if (m_huffmanSubset > 0) {
            sb.append("\n\n\tSubset size based on MHRanker: "
                    + Utils.doubleToString(m_huffmanSubset, 8, 4) + "\n");
        }

        return sb.toString();
    }

    /**
     * Resets stuff to default values
     */
    protected void resetOptions() {
        m_starting = null;
        m_startRange = new Range();
        m_attributeList = null;
        m_attributeMerit = null;
        m_numToSelect = -1;
    }

    private boolean inStarting(int feat) {
        // omit the class from the evaluation
        if ((m_hasClass == true) && (feat == m_classIndex)) {
            return true;
        }
        if (m_starting == null) {
            return false;
        }
        for (int element : m_starting) {
            if (element == feat) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the revision string.
     *
     * @return the revision
     */
    @Override
    public String getRevision() {
        return RevisionUtils.extract("$Revision: 11215 $");
    }


    public static double sum(BitSet bs, List<Double> ranks) {
        return bs.stream()
                .mapToDouble(i -> ranks.get(i))
                .sum();
    }

    public static List<Double> toList(double[] arr) {
        return Arrays.stream(arr)
                .boxed()
                .collect(Collectors.toList());
    }

    public static List<Double> normalize(List<Double> ranks) {
        //normalize dataset
        final double sumValue = ranks.stream()
                .mapToDouble(i -> i.doubleValue())
                .sum();

        if (sumValue == 0) throw new NullPointerException("Max Rank Can not be Zero !!");
        return ranks.stream()
                .map(v -> v / sumValue)
                .collect(Collectors.toList());
    }

    public static double huffman(double[] ranks) {
        return huffman(toList(ranks));
    }

    public static double huffman(List<Double> ranks) {
        List<Double> ranksN = normalize(ranks);

        Comparator<BitSet> comp = (o1, o2) -> (int) Math.signum(sum(o1, ranksN) - sum(o2, ranksN));

        List<BitSet> current = IntStream.range(0, ranks.size())
                .mapToObj(i -> {
                    BitSet bitSet = new BitSet(ranksN.size());
                    bitSet.set(i);
                    return bitSet;
                })
                .collect(Collectors.toList());

        double sum = 0.0;
        while (current.size() > 1) {
            BitSet min1 = Collections.min(current, comp);
            current.remove(min1);
            BitSet min2 = Collections.min(current, comp);
            current.remove(min2);

            BitSet merge = new BitSet(ranks.size());
            merge.or(min1);
            merge.or(min2);
            current.add(merge);
            sum += sum(merge, ranksN);
        }

        return Math.pow(2, sum);
    }
}
