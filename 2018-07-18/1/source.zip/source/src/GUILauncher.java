import weka.gui.GUIChooser;

public class GUILauncher {
    public static void main(String[] args) {
        GUIChooser.main(args);
    }
}
