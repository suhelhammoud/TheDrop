package sensetivity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import weka.attributeSelection.ASEvaluation;
import weka.attributeSelection.AttributeEvaluator;
import weka.attributeSelection.Ranker;
import weka.attributeSelection.pas.PasMethod;
import weka.attributeSelection.pas.PasUtils;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.AttributeSelection;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static sensetivity.TEvaluator.PAS;

public class StoryUtils {

    static Logger logger = LoggerFactory.getLogger(StoryUtils.class.getName());


    public static <T extends ASEvaluation & AttributeEvaluator> T getASEvaluation(Story story) {
        TEvaluator tEvaluator = (TEvaluator) story.get(StoryKey.evalMethod);
        switch (tEvaluator) {
            case PAS:
                double evalSupport = (double) story.get(StoryKey.evalSupport);
                double evalConfidence = (double) story.get(StoryKey.evalConfidence);

                PasMethod pasmethod = (PasMethod) story.get(StoryKey.pasMethod);

                return (T) PAS.getWith(evalSupport,
                        evalConfidence,
                        pasmethod);
            default:
                return (T) tEvaluator.get();
        }
    }

    public static AttributeSelection getAttributeSelection(Story story) {

        int numToSelect = (int) story.get(StoryKey.numAttributesToSelect);

        Ranker search = new Ranker();
        search.setNumToSelect(numToSelect);

        ASEvaluation evaluator = getASEvaluation(story);

        AttributeSelection result = new AttributeSelection();
        result.setEvaluator(evaluator);
        result.setSearch(search);
        return result;
    }

    public static Classifier getClassifier(Story story) {

        TClassifier tClassifier = (TClassifier) story.get(StoryKey.classifier);
        switch (tClassifier) {
            default:
                tClassifier.get();
        }
        return tClassifier.get(); //never reached !
    }

    public static Instances applyFilter(Story story, Instances data) throws Exception {

        int numAttributes = (int) story.get(StoryKey.numAttributes);
        int numToSelect = (int) story.get(StoryKey.numAttributesToSelect);

        if (numAttributes == numToSelect) {
            return new Instances(data);
        } else {

            AttributeSelection attEval = getAttributeSelection(story);
            attEval.setInputFormat(data);

            return Filter.useFilter(data, attEval);
        }
    }

    public static Story applyCrossValidation(
            Instances train,
            Classifier classifier)
            throws Exception {

        train.setClassIndex(train.numAttributes() - 1);
        Story result = Story.get();

        Evaluation eval = new Evaluation(train);
        //TODO change seed selection method
        eval.crossValidateModel(classifier, train, 10, new Random(1));
        result.set(StoryKey.errorRate, eval.errorRate());
        result.set(StoryKey.precision, eval.weightedPrecision());
        result.set(StoryKey.recall, eval.weightedRecall());
        result.set(StoryKey.fMeasure, eval.weightedFMeasure());
        return result;
    }


    public static Story playStory(Story story,
                                  Instances data,
                                  boolean withEntropy) {
        Story result = story; //mutual data structure
        try {
            Instances dataFiltered = applyFilter(story, data);
            assert (int) result.get(StoryKey.numAttributesToSelect) == dataFiltered.numAttributes() - 1;

            if (withEntropy) {
                List<Double> ranks = calcAndGetRanks(story, dataFiltered);

                double huffman = PasUtils.huffman(ranks);
                result.set(StoryKey.huffman, huffman);
            }

            Classifier classifier = getClassifier(story);
            Story cvStory = applyCrossValidation(dataFiltered, classifier);
            result.update(cvStory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    private static double evaluateAttribute(AttributeEvaluator attEval, int index) {
        try {
            return attEval.evaluateAttribute(index);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    public static List<Double> calcAndGetRanks(Story story, Instances data) {
        data.setClassIndex(data.numAttributes() - 1);

        ASEvaluation eval = getASEvaluation(story);
        try {
            eval.buildEvaluator(data);
        } catch (Exception e) {
            e.printStackTrace();
        }

        AttributeEvaluator attEval = (AttributeEvaluator) eval;
        return IntStream.range(0, data.numAttributes() - 1)
                .mapToDouble(i -> evaluateAttribute(attEval, i))
                .boxed()
                .collect(Collectors.toList());
    }

}
