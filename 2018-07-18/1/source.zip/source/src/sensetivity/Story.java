package sensetivity;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * General purpose data holder based on Map
 */
public class Story {
    private final AtomicLong ID = new AtomicLong();

    final private Map<StoryKey, Object> data;
    public final long id = ID.getAndIncrement();

    /**
     * Later stories would set the final values in the result
     *
     * @param stories
     * @return
     */
    public static Story of(Story... stories) {
        final Story result = new Story();
        Arrays.stream(stories).forEach(s -> {
            result.update(s);
        });
        return result;
    }

    /**
     * Mutual update
     *
     * @param that
     * @return
     */
    public Story update(Story that) {
        for (Map.Entry<StoryKey, Object> ent : that.data.entrySet()) {
            this.set(ent.getKey(), ent.getValue());
        }
        return this;
    }

    public static Story get() {
        return new Story();
    }

    public Story() {
        data = new HashMap<>(StoryKey.values().length);
    }

    public Object get(StoryKey key) {
        return data.get(key);
    }


    public Story set(StoryKey key, Object value) {
        data.put(key, value);
        return this;
    }

    public String stringValues() {
        return Arrays.stream(StoryKey.values())
                .map(key -> data.containsKey(key) ?
                        data.get(key).toString() :
                        "")
                .collect(Collectors.joining(", "));
    }

    @Override
    public String toString() {
        return stringValues();
    }
}
