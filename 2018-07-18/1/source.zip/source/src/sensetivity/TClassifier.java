package sensetivity;

import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;

public enum TClassifier {
    NB;

    public Classifier get() {
        switch (this) {
            case NB:
                return new NaiveBayes();
            default:
                System.err.println(name() + " unknown Classifier");
        }
        return null;
    }

    public Classifier getWith(Object... args) {
        switch (this) {
            default:
                return get();
        }
    }
}