package sensetivity;

import java.util.Arrays;
import java.util.stream.Collectors;

public enum StoryKey {

    dataset, //relation name, or dataset filename
    numInstances, // number of instances in the dataset
    numAttributes,// excluding the label class attribute
    evalMethod, //PAS, CHI, IG, ..etc
    pasMethod, //rules and rules1st
    evalSupport,// for PAS attribute selector only
    evalConfidence, // for PAS attribute selector only
    numAttributesToSelect, //for attribute selection filter
    huffman, //huffman threshold for num of attributes
    classifier, // NB

    /* Classification results */
    errorRate,
    precision,
    recall,
    fMeasure;

    public static String csvHeaders() {
        //TODO check EnumSet.allOf(StoryKey)
        return Arrays.stream(StoryKey.values())
                .map(item -> item.toString())
                .collect(Collectors.joining(", "));
    }
}
