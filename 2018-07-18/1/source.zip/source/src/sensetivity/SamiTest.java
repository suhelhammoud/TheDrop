package sensetivity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import weka.attributeSelection.pas.PasMethod;
import weka.attributeSelection.pas.PasUtils;
import weka.classifiers.Classifier;
import weka.core.Instances;

import java.io.FileReader;
import java.util.List;

public class SamiTest {

    final static Logger logger = LoggerFactory.getLogger(SamiTest.class.getName());

    private static void compare(double v1, double v2) throws Exception {
        final double epsilon = 1e06;
        if(v1 - v2 < epsilon) return;
        logger.error("compare v1= {} with v1 = {} ", v1, v2);
        throw new Exception(String.format("v1 = %f, does not equals v2 = %f", v1, v2));
    }

    public static void TT() throws Exception {
        Instances data = new Instances(new FileReader("data/arff/anneal.arff")); //choose correct path to run the test
//        Instances data = FilesUtils.instancesOf("data/arff/anneal.arff");
        data.setClassIndex(data.numAttributes() - 1);

        Story story = Story.get()
                .set(StoryKey.evalMethod, TEvaluator.PAS)
                .set(StoryKey.pasMethod, PasMethod.rules)
                .set(StoryKey.evalSupport, 0.01)
                .set(StoryKey.evalConfidence, 0.50)
                .set(StoryKey.classifier, TClassifier.NB)
                .set(StoryKey.dataset, data.relationName())
                .set(StoryKey.numInstances, data.numInstances())
                .set(StoryKey.numAttributes, data.numAttributes() - 1)
                .set(StoryKey.numAttributesToSelect, data.numAttributes() - 1);

        Instances dataFiltered = StoryUtils.applyFilter(story, data);
        List<Double> ranks = StoryUtils.calcAndGetRanks(story, dataFiltered);

        double huffman = PasUtils.huffman(ranks);
        story.set(StoryKey.huffman, huffman);


        Story result = StoryUtils.playStory(story, data, true);
        Classifier classifier = StoryUtils.getClassifier(story);

        Story cvStory = StoryUtils.applyCrossValidation(dataFiltered, classifier);

        result.update(cvStory);

        String dataset = (String) result.get(StoryKey.dataset);
        double errorRate = (double) result.get(StoryKey.errorRate);
        double precision = (double) result.get(StoryKey.precision);
        double huffmanO = (double)result.get(StoryKey.huffman);
        logger.info("\ndataname :{}\nerror_rate: {},\nprecision: {} \nhuffman: {}",
                dataset,
                errorRate,
                precision,
                huffmanO);

        if(!dataset.equals("anneal")){
            logger.error("dataset {} does not equal anneal", dataset);
            throw new Exception("dataset not ok " + dataset);
        }
        compare(errorRate, 0.13697104677060135);
        compare(precision, 0.9326420393739496);
        compare(huffmanO, 0.9326420393739496);

        System.out.println("\nAll test are done successfully");

    }

    public static void main(String[] args) throws Exception {
        TT();
    }
}
